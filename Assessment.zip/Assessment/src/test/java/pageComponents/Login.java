package pageComponents;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import utilityComponents.Base;

public class Login {

	public WebDriver driver;

	@FindBy(xpath = "//input[@id='identifierId']")
	public WebElement username;

	@FindBy(xpath = "//div[@id='identifierNext']//span[@class='VfPpkd-vQzf8d']")
	public WebElement userclick;

	@FindBy(xpath = "//input[contains(@type,'password')]/preceding::div[@class='rn19nc']/following-sibling::div[@class='rhhJr']")
	public WebElement password;

	@FindBy(xpath = "//span[text()='Next']")
	public WebElement passclick;
	
	@FindBy(xpath ="//a[@class='gb_ke gb_vc gb_ie']")
	public WebElement gettitle;
	
	
	Base b = new Base();

	public Login() {

		this.driver = Base.driver;
		PageFactory.initElements(driver, this);

	}

	public void loginpage() throws Throwable {
		username.sendKeys(Base.propvalue("USERNAME"));		
		userclick.click();
		password.sendKeys(Base.propvalue("PASSWORD"));
		passclick.click();
	}
	public void navigatespage() {
		
		String text = gettitle.getText();
		assertTrue(true, text);
		

	}

}
