package pageComponents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilityComponents.Base;

public class MessagePage {
	public WebDriver driver;
	
	@FindBy(xpath = "//div[@class='T-I T-I-KE L3']")
	public WebElement compose;
	
	@FindBy(xpath = "//input[@id=':vv']")
	public WebElement sendto;
	
	@FindBy(xpath = "//input[@id=':ty']")
	public WebElement subject;
	
	@FindBy(xpath = "//div[@id=':15b']")
	public WebElement body;
	
	@FindBy(xpath = "//div[@id=':13u']")
	public WebElement sendbutton;
	
	
	
	


	
	
	Base b = new Base();

	public MessagePage() {

		this.driver = Base.driver;
		PageFactory.initElements(driver, this);

	}
	public void composepage() throws Throwable {
		compose.click();

	}
	public void sendmessage() {
		sendto.sendKeys("kumarvishnu20@gmail.com");
		subject.sendKeys("Incubyte");
		body.sendKeys("Automation QA test for Incubyte");
		sendbutton.click();
		

	}

}
