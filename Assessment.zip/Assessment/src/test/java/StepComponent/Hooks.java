package StepComponent;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import utilityComponents.Base;

public class Hooks extends Base {
	
	@Before
	public void landinpage() throws Throwable {
		setdriver("chrome");
		launchurl(propvalue("URL"));

	}
	@After
	public void afterhooks() {
      driver.quit();
	}

	
	}





