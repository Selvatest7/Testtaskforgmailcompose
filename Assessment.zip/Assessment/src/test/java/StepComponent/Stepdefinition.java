package StepComponent;

import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageComponents.Login;
import pageComponents.MessagePage;
import utilityComponents.Base;

public class Stepdefinition extends Base {
	Login  l = new Login();
	MessagePage m = new MessagePage();

	@When("User enter the login credentials")
	public void user_enter_the_login_credentials() throws Throwable {
		getwait().until(ExpectedConditions.visibilityOf(l.username));
		l.loginpage();
	 
	}

	@Then("User navigates to the main page")
	public void user_navigates_to_the_main_page() {
		l.navigatespage();
	}

	@Given("User click the compose button")
	public void user_click_the_compose_button() throws Throwable {
		getwait().until(ExpectedConditions.visibilityOf(m.compose));
		m.composepage();

		
		
	}

	@When("User enter the message credentials")
	public void user_enter_the_message_credentials() {
		getwait().until(ExpectedConditions.visibilityOf(m.sendto));
		m.sendmessage();
		
	}

	@Then("User click the send button")
	public void user_click_the_send_button() {
		getwait().until(ExpectedConditions.elementToBeClickable(m.sendbutton));
		m.sendmessage();
	}

}
