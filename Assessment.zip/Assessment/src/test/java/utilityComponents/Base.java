package utilityComponents;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Base {
	public static WebDriver driver;
	public static WebElement element;
	public static WebDriverWait wait;
	
	public static void setdriver(String browser) {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		

	}
	public static WebDriver getdriver() {
		return driver;

	}
	public static boolean launchurl(String url) {
		boolean flag=false;
		try {
			driver.get(url);
			flag=false;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;

	}
	public static WebDriverWait getwait() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		return wait;

	}
	public static String propvalue(String key) throws IOException {
		String value = null;
		try {
			FileReader reader = new FileReader("config.properties");
			Properties prop = new Properties();
			prop.load(reader);
			value = prop.getProperty(key);

		} catch(Exception e) {
			e.printStackTrace();
		}
		return value;

	}
	
	
	
	
}
